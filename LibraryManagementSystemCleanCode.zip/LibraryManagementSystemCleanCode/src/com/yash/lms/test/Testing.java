package com.yash.lms.test;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.rules.TemporaryFolder;
import org.junit.rules.Timeout;

import com.yash.lms.LMSEntryPoint;

public class Testing {

	@Rule
	public ExpectedException exception = ExpectedException.none();
	
	@Rule
	public TemporaryFolder folder = new TemporaryFolder();
	
	@Test
	@Ignore
	public void useCase() {
		System.out.println("Testing.useCase(), Adding value: 2 and null");
		LMSEntryPoint obj = new LMSEntryPoint();
		exception.expect(NullPointerException.class);
		obj.sum(2, null);
	}
	
	@Test
	@Ignore
	public void useCase2() throws IOException {
		System.out.println("Testing.useCase2()");
		File createdFolder = folder.newFolder("tempFolder");
		File createdFile = folder.newFile("tempFile.txt");

		assertTrue(createdFolder.exists());
		assertTrue(createdFile.exists());
		
	}
	
	@Test
	public void useCaseAssertion() {
		
		System.out.println("Testing.useCase1()");
		
		String obj1 = "junit";
		String obj2 = "junit";
		String obj3 = "test";
		String obj4 = "test";
		String obj5 = null;
		int var1 = 10;
		int var2 = 20;
		int[] array1 = {1,2,3};
		int[] array2 = {7,8,9};
		
//		assertEquals(obj1, obj2);
//		assertSame(obj3, obj4);
//		assertNotSame(obj2, obj4);
//		assertNotNull("Value of obj5 is null", obj5);
		assertThat("geek", is("geek"));
//		assertNull(obj5);
//		assertArrayEquals(array1, array2);
//		assertTrue(obj2==obj3);
		
		
		
	}
	
	@BeforeClass
	public static void beforeClass() {
		System.out.println("Testing.beforeClass()");
	}
	
	@Before
	public void before() {
		System.out.println("Testing.before()");
	}
	
	@After
	public void after() {
		System.out.println("Testing.after()");
	}

	@AfterClass
	public static void afterClass() {
		System.out.println("Testing.afterClass()");
	}
}
